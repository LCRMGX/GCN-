# RNN
Landslide susceptibility analysis using traditional RNN, LSTM, GRU and SRU.
